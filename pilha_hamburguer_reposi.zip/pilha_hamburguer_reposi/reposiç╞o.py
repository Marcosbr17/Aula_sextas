def pilha_de_livros():
    pilha = []
    
    while True:
        print("\n--- PILHA DE LIVROS ---")
        print("1 - Adicionar livro")
        print("2 - Remover livro")
        print("3 - Ver livro do topo")
        print("4 - Mostrar pilha")
        print("5 - Sair")
        
        opcao = input("Opção: ")
        
        if opcao == "1":
            livro = input("Nome do livro: ")
            pilha.append(livro)
            print(f"'{livro}' adicionado!")
        
        elif opcao == "2":
            if pilha:
                removido = pilha.pop()
                print(f"'{removido}' removido!")
            else:
                print("Pilha vazia!")
        
        elif opcao == "3":
            if pilha:
                print(f"Livro do topo: '{pilha[-1]}'")
            else:
                print("Pilha vazia!")
        
        elif opcao == "4":
            if pilha:
                print("\nPILHA DE LIVROS (do topo para baixo):")
                for livro in reversed(pilha):
                    print(f"- {livro}")
            else:
                print("Pilha vazia!")
        
        elif opcao == "5":
            print("Saindo...")
            break
        
        else:
            print("Opção inválida!")

pilha_de_livros()