def montar_sanduiche():
    sanduiche = []
    
    print("=== MONTADOR DE SANDUÍCHE ===")
    
    while True:
        print("\nMENU:")
        print("1 - Adicionar ingrediente")
        print("2 - Remover ingrediente")
        print("3 - Ver último ingrediente")
        print("4 - Mostrar sanduíche")
        print("5 - Finalizar pedido")
        
        opcao = input("Escolha uma opção: ")
        
        if opcao == "1":
            ingrediente = input("Digite o ingrediente: ")
            if ingrediente:
                sanduiche.append(ingrediente)
                print(f"'{ingrediente}' adicionado!")
            else:
                print("Ingrediente inválido!")
        
        elif opcao == "2":
            if sanduiche:
                removido = sanduiche.pop()
                print(f"'{removido}' removido!")
            else:
                print("Sanduíche vazio!")
        
        elif opcao == "3":
            if sanduiche:
                print(f"Último: '{sanduiche[-1]}'")
            else:
                print("Sanduíche vazio!")
        
        elif opcao == "4":
            if sanduiche:
                print("\nSEU SANDUÍCHE:")
                print("Pão de baixo")
                for ingrediente in sanduiche:
                    print(ingrediente)
                print("Pão de cima")
            else:
                print("Sanduíche vazio!")
        
        elif opcao == "5":
            print("\nPedido finalizado!")
            if sanduiche:
                print("Ingredientes no sanduíche:")
                for ingrediente in sanduiche:
                    print(f"- {ingrediente}")
            break
        
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    montar_sanduiche()