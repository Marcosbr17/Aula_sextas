#include <stdio.h>

int main() {
    double num1, num2, soma;
    printf("Digite o primeiro número: ");
    scanf("%lf", &num1);
    printf("Digite o segundo número: ");
    scanf("%lf", &num2);
    soma = num1 + num2;
    printf("A soma de %.2f + %.2f = %.2f\n", num1, num2, soma);
    return 0;
}