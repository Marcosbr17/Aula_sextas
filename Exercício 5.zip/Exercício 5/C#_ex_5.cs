using System;

class Program {
    static void Main() {
        Console.Write("Digite o primeiro número: ");
        double num1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Digite o segundo número: ");
        double num2 = Convert.ToDouble(Console.ReadLine());
        double soma = num1 + num2;
        Console.WriteLine($"A soma de {num1} + {num2} = {soma}");
    }
}