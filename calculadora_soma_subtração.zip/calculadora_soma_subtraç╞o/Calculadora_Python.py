# Solicitação dos valores e conversão de string para inteiro
num1 = int(input("\nDigite o primeiro número: "))
num2 = int(input("\nDigite o segundo número (diferente de zero): "))

# Declaração das variáveis para armazenar os resultados
soma = num1 + num2
sub = num1 - num2
mult = num1 * num2
div = num1 / num2  # Em Python, a divisão já é float por padrão

# Exibição dos resultados das operações ao final
print("\nResultados:")
print("Soma:", soma)
print("Subtração:", sub)
print("Multiplicação:", mult)
print("Divisão:", div)
