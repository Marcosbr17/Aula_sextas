#include <iostream>
using namespace std;

int main() {
    float compra;
    
    cout << "Qual o valor da compra? ";
    cin >> compra;
    
    if (compra >= 100) {
        cout << "Frete Grátis" << endl;
        cout << "Valor total: " << compra << endl;
    }
    
    if (compra < 100) {
        float total;
        total = compra + 15;
        cout << "Total com frete: " << total << endl;
    }
    
    system("pause");
    return 0;
}