using System;

class Program
{
    static void Main()
    {
        float n;
        
        Console.WriteLine("Coloca a nota ai: ");
        n = float.Parse(Console.ReadLine());
        
        if (n <= 5.0)
        {
            Console.WriteLine("Reprovado");
        }
        
        if (n > 5.0 && n <= 6.0)
        {
            Console.WriteLine("Recuperação");
        }
        
        if (n > 6.0)
        {
            Console.WriteLine("Aprovado");
        }
        
        Console.ReadLine();
    }
}