cor = input("Fala uma cor primária: ")

if cor == "vermelho":
    print("🔴VERMELHO: calor, energia, perigo")

if cor == "azul":
    print("🔵AZUL: calma, inteligência, frio")

if cor == "amarelo":
    print("🟡AMARELO: alegria, riqueza, luz")

if cor != "vermelho" and cor != "azul" and cor != "amarelo":
    print("Essa cor não faz parte das cores primárias!")