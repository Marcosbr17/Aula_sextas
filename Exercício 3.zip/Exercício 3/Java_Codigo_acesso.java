import java.util.Scanner;

public class Teste {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String cod;
        
        System.out.print("Código: ");
        cod = scan.next();
        
        if (cod.equals("Admin123")) {
            System.out.println("✅ Bem-vindo, Administrador!");
        } else if (cod.equals("User123")) {
            System.out.println("✅ Bem-vindo, Usuário!");
        } else {
            System.out.println("❌ Código incorreto");
        }
        
        scan.close();
    }
}